//
//  NSMutableArray+IntExt.m
//  CategoryTest
//
//  Created by T1 on 13. 1. 4..
//  Copyright (c) 2013년 T1. All rights reserved.
//

#import "NSMutableArray+IntExt.h"

@implementation NSMutableArray (IntExt)

-(void)addInt:(int)value
{
    NSNumber *num = [NSNumber numberWithInt:value];
    [self addObject:num];
}

-(int)intAtIndex:(int)index
{
    NSNumber *num = [self objectAtIndex:index];
    return [num intValue];
}

@end
