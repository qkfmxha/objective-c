//
//  main.m
//  CategoryTest
//
//  Created by T1 on 13. 1. 4..
//  Copyright (c) 2013년 T1. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSMutableArray+IntExt.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSMutableArray *arr = [[NSMutableArray alloc] init];
        
        [arr addObject:[NSNumber numberWithInt:10]];
        [arr addInt:20];
        
        // insert code here...
        NSNumber *num = [arr objectAtIndex:0];
        NSLog(@"0:%d, 1:%d", [num intValue], [arr intAtIndex:1]);
        
    }
    return 0;
}

