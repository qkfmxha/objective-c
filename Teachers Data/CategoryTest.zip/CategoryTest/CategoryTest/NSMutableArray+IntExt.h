//
//  NSMutableArray+IntExt.h
//  CategoryTest
//
//  Created by T1 on 13. 1. 4..
//  Copyright (c) 2013년 T1. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (IntExt)

-(void)addInt:(int)value;
-(int)intAtIndex:(int)index;

@end
