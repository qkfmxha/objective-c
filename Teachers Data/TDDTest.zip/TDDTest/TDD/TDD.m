//
//  TDD.m
//  TDD
//
//  Created by T1 on 13. 1. 4..
//  Copyright (c) 2013년 T1. All rights reserved.
//

#import "TDD.h"
#import "MyClass.h"

@implementation TDD

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testAdd
{
    MyClass *obj = [[MyClass alloc] init];
    
    STAssertEquals(3, [obj add:1 and:2], @"계산결과가 틀리다");
}

- (void)testAdd2
{
    MyClass *obj = [[MyClass alloc] init];
    
    STAssertEquals(4, [obj add:1 and:2], @"계산결과가 틀리다");
}

@end
