//
//  MyClass.m
//  TDDTest
//
//  Created by T1 on 13. 1. 4..
//  Copyright (c) 2013년 T1. All rights reserved.
//

#import "MyClass.h"

@implementation MyClass

- (int)add:(int)i and:(int)j
{
    return i+j;
}

@end
