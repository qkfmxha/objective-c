//
//  ViewController.h
//  ClassTestApp
//
//  Created by T1 on 13. 1. 3..
//  Copyright (c) 2013년 T1. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyRedButton.h"

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>

@property (retain, nonatomic) IBOutlet UITextField *myTextField;
@property (retain, nonatomic) IBOutlet UITableView *myTableView;
@property (retain, nonatomic) IBOutlet UIButton *leftButton;
@property (retain, nonatomic) IBOutlet UIButton *rightButton;

@property (copy, nonatomic) NSString *singerName;
@property (retain, nonatomic) MyRedButton *redButton;

@property (retain, nonatomic) NSArray *nameArray;

@end
