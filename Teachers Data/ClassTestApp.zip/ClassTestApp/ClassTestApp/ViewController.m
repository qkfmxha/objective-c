//
//  ViewController.m
//  ClassTestApp
//
//  Created by T1 on 13. 1. 3..
//  Copyright (c) 2013년 T1. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize redButton;

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

#if 1
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.nameArray.count;
}
#endif

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    cell.textLabel.text = [self.nameArray objectAtIndex:indexPath.row];
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
#if 1
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"%d, [didSelectRowAtIndexPath] : %@", tableView.tag, indexPath);
}
#endif

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    NSLog(@"textFieldDidBeginEditing");
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    NSLog(@"textFieldDidEndEditing");
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    
    //self.myTextField.delegate = self;
    
    
    
    [self.leftButton setTitle:@"Left Button" forState:UIControlStateNormal];
    
    self.singerName = [NSString stringWithFormat:@"Test"];
    
    self.redButton = [[MyRedButton alloc] init];
    
    self.myTableView.dataSource = self;
    self.myTableView.delegate = self;
    self.nameArray = [NSArray arrayWithObjects:@"김태희",@"비",@"소녀시대", nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    
    [self.redButton release];
    
    [self.singerName release];
    
    [self.leftButton release];
    [self.rightButton release];
    [_myTableView release];
    [_myTextField release];
    [super dealloc];
}

@end
