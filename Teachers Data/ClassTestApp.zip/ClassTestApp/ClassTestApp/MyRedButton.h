//
//  MyRedButton.h
//  ClassTestApp
//
//  Created by T1 on 13. 1. 3..
//  Copyright (c) 2013년 T1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyRedButton : UIButton

@end
