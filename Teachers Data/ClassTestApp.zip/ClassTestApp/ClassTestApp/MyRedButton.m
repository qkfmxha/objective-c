//
//  MyRedButton.m
//  ClassTestApp
//
//  Created by T1 on 13. 1. 3..
//  Copyright (c) 2013년 T1. All rights reserved.
//

#import "MyRedButton.h"

@implementation MyRedButton

- (void)dealloc
{
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        // Initialization code
        
        UIImage *img = [UIImage imageNamed:@"redButton.png"];
        [self setImage:img forState:UIControlStateNormal];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
