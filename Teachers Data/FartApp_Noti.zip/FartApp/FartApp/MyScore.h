//
//  MyScore.h
//  FartApp
//
//  Created by T1 on 13. 1. 4..
//  Copyright (c) 2013년 T1. All rights reserved.
//

#import <Foundation/Foundation.h>

#define ADD_SCORE_NOTI_NAME         @"점수올려~~"

@interface MyScore : NSObject

@property int score;

- (void)addScore:(int)aScore;
- (void)printScore;

@end
