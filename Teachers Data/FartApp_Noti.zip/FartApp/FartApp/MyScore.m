//
//  MyScore.m
//  FartApp
//
//  Created by T1 on 13. 1. 4..
//  Copyright (c) 2013년 T1. All rights reserved.
//

#import "MyScore.h"

@implementation MyScore

- (void)handlNotification:(NSNotification *)noti
{
    NSDictionary *userInfo = [noti userInfo];
    
    self.score += [[userInfo objectForKey:@"추가할점수"] intValue];
    
    [self printScore];
}

- (id)init
{
    self = [super init];
    if (self)
    {
        NSNotificationCenter *defaultCenter = [NSNotificationCenter defaultCenter];
        
        SEL s = @selector(handlNotification:);
        
        [defaultCenter addObserver:self selector:s name:ADD_SCORE_NOTI_NAME object:nil];
    }
    
    return self;
}

- (void)addScore:(int)aScore
{
    self.score += aScore;
}

- (void)printScore
{
    NSLog(@"현재점수 : %d 입니다", self.score);
}

@end
