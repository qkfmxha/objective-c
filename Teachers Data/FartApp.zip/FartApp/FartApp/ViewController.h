//
//  ViewController.h
//  FartApp
//
//  Created by T1 on 13. 1. 4..
//  Copyright (c) 2013년 T1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)leftButPressed:(id)sender;
- (IBAction)rightButPressed:(id)sender;
@end
