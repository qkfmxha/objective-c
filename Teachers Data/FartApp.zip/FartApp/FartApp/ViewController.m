//
//  ViewController.m
//  FartApp
//
//  Created by T1 on 13. 1. 4..
//  Copyright (c) 2013년 T1. All rights reserved.
//

#import "ViewController.h"
#import <AudioToolbox/AudioToolbox.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)playFartSound
{
    NSLog(@"playFartSound");
    
    SystemSoundID ssid;
    // 사운드 파일을 생성합니다.
    NSString *sndPath = [[NSBundle mainBundle] pathForResource:@"fart.caf" ofType:nil inDirectory:@"/"];
    // URL을 생성합니다
    CFURLRef sndURL = (CFURLRef)[[NSURL alloc] initFileURLWithPath:sndPath];
    // 사운드 아이디를 생성합니다.
    AudioServicesCreateSystemSoundID(sndURL, &ssid);
    
    AudioServicesPlaySystemSound(ssid);
}

- (IBAction)leftButPressed:(id)sender {
    NSLog(@"leftButPressed");
    
    SEL s = @selector(playFartSound);
    [self performSelector:s withObject:nil afterDelay:3];
}

- (IBAction)rightButPressed:(id)sender {
    NSLog(@"rightButPressed");
    
    SEL s = @selector(playFartSound);
    [self performSelector:s withObject:nil afterDelay:5];
}

@end
