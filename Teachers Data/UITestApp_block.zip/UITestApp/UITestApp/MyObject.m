//
//  MyObject.m
//  UITestApp
//
//  Created by T1 on 13. 1. 4..
//  Copyright (c) 2013년 T1. All rights reserved.
//

#import "MyObject.h"

@implementation MyObject

- (void)dealloc
{
    NSLog(@"MyObject dealloc");
    [super dealloc];
}


@end
