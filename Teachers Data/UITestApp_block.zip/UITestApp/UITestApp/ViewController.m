//
//  ViewController.m
//  UITestApp
//
//  Created by T1 on 13. 1. 3..
//  Copyright (c) 2013년 T1. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    //self.myString = [[[NSString alloc] initWithString:@"Hello World"] autorelease];
    self.myString = [NSString stringWithString:@"Hello World %d"];
    
    CGRect labelFrame = CGRectMake(147,265, 80,40);
    UILabel *newLabel = [[UILabel alloc] initWithFrame:labelFrame];
    newLabel.backgroundColor = [UIColor redColor];
    newLabel.textColor = [UIColor whiteColor];
    newLabel.text = self.myString;
    
    self.myLabel = newLabel;
    [newLabel release];
    
    // 화면에 보이게 붙인다
    [self.view addSubview:self.myLabel];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [self.myLabel release];
    [self. myString release];
    
    [_helloTextLabel release];
    [_rainImageView release];
    [_kimImageView release];
    [super dealloc];
}

- (void)moveHelloLabelWithAni:(int)i time:(int)j type:(int)k
{
#if 0
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:3];
    self.helloTextLabel.center = CGPointMake(160, 100);
    [UIView commitAnimations];
#else
    
    void (^myAniBlock)(void) = ^{
        self.helloTextLabel.center = CGPointMake(160, 100);
    };
    
    void (^myAniCompletionBlock)(BOOL) = ^(BOOL finished) {
        self.helloTextLabel.backgroundColor = [UIColor redColor];
    };
    
    //[UIView animateWithDuration:2.0 animations:myAniBlock];
    [UIView animateWithDuration:5 delay:0.1 options:UIViewAnimationOptionCurveEaseInOut animations:myAniBlock completion:myAniCompletionBlock];
    
    
    
#endif
}

- (void)moveHelloLabel
{
    self.helloTextLabel.text = @"ObjC 강의장입니다";
    self.helloTextLabel.center = CGPointMake(160, 300);
}

- (IBAction)butPressed:(id)sender {
    SEL s = @selector(moveHelloLabel);
    [self performSelector:s withObject:nil afterDelay:3.0];

    NSLog(@"butPressed");
}

- (IBAction)sliderChanged:(UISlider *)sender {
    NSLog(@"sliderChanged : %f", sender.value);

    self.kimImageView.alpha = sender.value;
    self.rainImageView.alpha = 1.0-sender.value;
}

- (IBAction)aniButPressed:(id)sender {
    SEL s = @selector(moveHelloLabelWithAni:time:type:);
    [self performSelector:s withObject:nil afterDelay:1.0];

    NSLog(@"aniButPressed");
}

@end
